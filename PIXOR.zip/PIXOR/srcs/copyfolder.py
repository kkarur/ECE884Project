import shutil
import os
    
source_dir = '/content/PIXOR/srcs/training'
source_dir1 = '/content/PIXOR/srcs/testing'
target_dir = '/content/PIXOR/srcs/data_object_velodyne'
    
shutil.move(source_dir, target_dir)
shutil.move(source_dir1, target_dir)