import os
import time 
import numpy as np
import torch
import torch.nn as nn
from helper_lib import build_model, load_config, get_bev, plot_bev, get_model_name
import ctypes
from postprocess import filter_pred

LidarLib = ctypes.cdll.LoadLibrary('preprocess/LidarPreprocess.so')

print("Entry")
def rt_predict():#run predition on a given file. 
	print("Entry")
	device='cpu' #cuda fast evaluation
	config, _, _, _ = load_config('default') 
	net, loss_fn = build_model(config, device, train=False) #computing the loss between actual output and true output
	net.load_state_dict(torch.load(get_model_name(config), map_location=device)) #start from pre trained state
	net.set_decode(True)
	net.eval() #setting only evaluation
	rt_data_path="/content/PIXOR/srcs/frame.bin" #file that we need to run
	print("Entry")
	geometry = {
		'L1': -40.0, #sides
		'L2': 40.0,
		'W1': 0.0, #front and back
		'W2': 70.0,
		'H1': -3.5, #above and below
		'H2': 0.0,
		'input_shape': (800, 700, 36), #convert point cloud data to image like structure
		'label_shape': (200, 175, 7)} #output of the network is .25 times the input

	target_mean = np.array([0.008, 0.001, 0.202, 0.2, 0.43, 1.368]) #pre-computed mean and Standard deviation x-y-z
	target_std_dev = np.array([0.866, 0.5, 0.954, 0.668, 0.09, 0.111])
	print("middle")
	with torch.no_grad(): #No backpropagation, no gradient as we are not training
		c_name = bytes(rt_data_path, 'utf-8')
		scan = np.zeros(geometry['input_shape'], dtype=np.float32)
		c_data = ctypes.c_void_p(scan.ctypes.data)
		LidarLib.createTopViewMaps(c_data, c_name) #point cloud data into image like structure and its done in c language 37 to 40
		print(sum(sum(sum(scan))))
		scan = torch.from_numpy(scan) #conversion
		scan = scan.permute(2, 0, 1) #a x b x c to c x a x b this is because network accepts in a perticular format
		scan = scan.to(device) #pushing data onto Cpu/Gpu

		pred = net(scan.unsqueeze(0)) #prediting output for a given scan
		pred.squeeze_(0)
		corners, scores = filter_pred(config, pred) #post processing the results
		scan_np = scan.cpu().permute(1, 2, 0).numpy() # convert back to a b c
		plot_bev(scan_np,corners,window_name="pred",save_path='./Prediction.png') #bounding box 
print("end")
rt_predict()


