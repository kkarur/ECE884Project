import numpy as np
import csv
import os

path="/content/PIXOR/srcs/test"
files = os.listdir(path)
from numpy import genfromtxt


for file_name in files:
	file_name = os.path.join(path,file_name)
	if(os.path.isfile(file_name)):
		print(file_name)
		#temp = np.fromfile(file_name, dtype=np.float32)
		temp = genfromtxt(file_name, delimiter=',')
		temp.astype('float32').tofile("./frame.bin")