
import numpy as np
import csv
import os

path="/content/PIXOR/srcs/test"
files = os.listdir(path)

for file_name in files:
	file_name = os.path.join(path,file_name)
	out_name=file_name[:-4]+'.csv'
	data = np.fromfile(file_name, dtype=np.float32).reshape(-1, 4)
	np.savetxt(out_name, data, delimiter=",")